public class GameSettings {
}
